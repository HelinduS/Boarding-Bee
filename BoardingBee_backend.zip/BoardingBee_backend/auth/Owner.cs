using System.ComponentModel.DataAnnotations;

namespace BoardingBee_backend.Auth.Models
{
    public class Owner : User
    {
        // Additional properties for Owners can be added here
    }
}
