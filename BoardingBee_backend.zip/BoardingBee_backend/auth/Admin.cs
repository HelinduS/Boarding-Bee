using System.ComponentModel.DataAnnotations;

namespace BoardingBee_backend.Auth.Models
{
    public class Admin : User
    {
        // Additional properties for Admins can be added here
    }
}
